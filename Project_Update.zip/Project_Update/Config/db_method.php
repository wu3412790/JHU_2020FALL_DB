<?php
    function get_Country($db,$country){
        $sql="SELECT country_info.Country,daily_global.New_Cases,daily_global.Date_Recorded FROM country_info  LEFT JOIN daily_global ON country_info.Country_Code=daily_global.Country_Code WHERE country_info.Country='$country' ORDER BY daily_global.Year ASC, daily_global.Month ASC, daily_global.Day ASC";
        $result = $db->query($sql);
        if($result){
            $infos = array();
            while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
                $infos[] = $row;
            }

        }
        return $infos;
    }
?>