<?php


class DB_class
{

    function __construct()
    {

        $servername = "dbase.cs.jhu.edu"; // database server name
        $username = "20fa_yzhou144"; // dbase username
        $password = "66usGJSQV4"; // dbase password
        $dbname = "20fa_yzhou144_db"; // name of db 
        $this->mysqli = new mysqli($servername, $username, $password, $dbname);
        if ($this->mysqli->connect_error) {
            die('Connect Error (' . $this->mysqli->connect_errno . ') ' . $this->mysqli->connect_error);
        }
        $this->query("SET NAMES UTF8");
    }
    function mysql_fetch_array($result){
        return $result->fetch_array(MYSQLI_ASSOC);
    }
    function query($sql)
    {
        return $this->mysqli->query($sql);
    }

}
