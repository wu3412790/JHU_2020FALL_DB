﻿<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search</title>
    <script src="static/js/echarts.js"></script>
    <link href="static/css/columnDrag.css" rel="stylesheet" type="text/css">
</head>
<?php
define("PATH", dirname(__FILE__));
include 'Config/DB_class.php';
include 'Config/db_method.php';
$db = new DB_class();

?>
<?php
$date=$_POST['date'];
$country=$_POST['country'];
$_sql="";
if($date!="" && $country!=""){
    $sql="SELECT 

country_info.Country,
country_info.Continent,
daily_global.Date_Recorded,
daily_global.New_Cases,
daily_global.New_Deaths,
country_info.Population,
country_info.Population_Density,
country_info.Median_Age,
country_info.Aged_65_Older,
country_info.Aged_70_Older,
country_info.GDP_Per_Capita,
country_info.Extreme_Poverty,
country_info.Cardiovasc_Death_Rate,
country_info.Diabetes_Prevalence,
country_info.Female_Smokers,
country_info.Male_Smokers,
country_info.Handwashing_Facilities,
country_info.Hospital_Beds_Per_Thousand,
country_info.Life_Expectancy,
country_info.Human_Development_Index                                                                   
 FROM
country_info LEFT JOIN daily_global ON country_info.Country_Code=daily_global.Country_Code WHERE country_info.Country LIKE '%$country%'  AND daily_global.Date_Recorded LIKE '%$date%'";
}
else if($country!=""){
    $sql="SELECT 

country_info.Country,
country_info.Continent,
daily_global.Date_Recorded,
daily_global.New_Cases,
daily_global.New_Deaths,
country_info.Population,
country_info.Population_Density,
country_info.Median_Age,
country_info.Aged_65_Older,
country_info.Aged_70_Older,
country_info.GDP_Per_Capita,
country_info.Extreme_Poverty,
country_info.Cardiovasc_Death_Rate,
country_info.Diabetes_Prevalence,
country_info.Female_Smokers,
country_info.Male_Smokers,
country_info.Handwashing_Facilities,
country_info.Hospital_Beds_Per_Thousand,
country_info.Life_Expectancy,
country_info.Human_Development_Index                                                                   
 FROM
country_info LEFT JOIN daily_global ON country_info.Country_Code=daily_global.Country_Code WHERE country_info.Country LIKE '%$country%'";
}
else if($date!=""){
    $sql="SELECT 

country_info.Country,
country_info.Continent,
daily_global.Date_Recorded,
daily_global.New_Cases,
daily_global.New_Deaths,
country_info.Population,
country_info.Population_Density,
country_info.Median_Age,
country_info.Aged_65_Older,
country_info.Aged_70_Older,
country_info.GDP_Per_Capita,
country_info.Extreme_Poverty,
country_info.Cardiovasc_Death_Rate,
country_info.Diabetes_Prevalence,
country_info.Female_Smokers,
country_info.Male_Smokers,
country_info.Handwashing_Facilities,
country_info.Hospital_Beds_Per_Thousand,
country_info.Life_Expectancy,
country_info.Human_Development_Index                                                                   
 FROM
country_info LEFT JOIN daily_global ON country_info.Country_Code=daily_global.Country_Code WHERE daily_global.Date_Recorded like '%$date%'";
    
}
else{
    $sql="";

}
$infos = array();
if($sql){
    $result = $db->query($sql);
    while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
        $infos[] = $row;
    }
}
?>
<body>
    <?php include "Header.php"?>
    <div class="search_bg">
        <form method="post">
            <input type="text" name="date" placeholder="For example:day/month/year">
            <input type="text" name="country" placeholder="country">
            <input type="submit" value="search">
        </form>
    </div>
    <div id="chenkbox">
        <table id="tableSort">
            <tr>
                <th onclick="sortTable('tableSort',0)" title="Click Sort">Country</th>
                <th onclick="sortTable('tableSort',1)" title="Click Sort">Continent</th>
                <th onclick="sortTable('tableSort',2)" title="Click Sort">Date_Recorded</th>
                <th onclick="sortTable('tableSort',3)" title="Click Sort">New_Cases</th>
                <th onclick="sortTable('tableSort',4)" title="Click Sort">New_Deaths</th>
                <th onclick="sortTable('tableSort',4)" title="Click Sort">Population</th>
                <th onclick="sortTable('tableSort',5)" title="Click Sort">Population_Density</th>
                <th onclick="sortTable('tableSort',6)" title="Click Sort">Median_Age</th>
                <th onclick="sortTable('tableSort',7)" title="Click Sort">Aged_65_Older</th>
                <th onclick="sortTable('tableSort',8)" title="Click Sort">Aged_70_Older</th>
                <th onclick="sortTable('tableSort',9)" title="Click Sort">GDP_Per_Capita</th>
                <th onclick="sortTable('tableSort',10)" title="Click Sort">Extreme_Poverty</th>
                <th onclick="sortTable('tableSort',11)" title="Click Sort">Cardiovasc_Death_Rate</th>
                <th onclick="sortTable('tableSort',12)" title="Click Sort">Diabetes_Prevalence</th>
                <th onclick="sortTable('tableSort',13)" title="Click Sort">Female_Smokers</th>
                <th onclick="sortTable('tableSort',14)" title="Click Sort">Male_Smokers</th>
                <th onclick="sortTable('tableSort',15)" title="Click Sort">Handwashing_Facilities</th>
                <th onclick="sortTable('tableSort',16)" title="Click Sort">Hospital_Beds_Per_Thousand</th>
                <th onclick="sortTable('tableSort',17)" title="Click Sort">Life_Expectancy</th>
                <th onclick="sortTable('tableSort',18)" title="Click Sort">Human_Development_Index   </th>
            </tr>
            <?php foreach($infos as $info): ?>
            <tr>
                <td><?php  echo $info["Country"] ?></td>
                <td><?php  echo $info["Continent"] ?></td>
                <td><?php  echo $info["Date_Recorded"] ?></td>
                <td><?php  echo $info["New_Cases"] ?></td>
                <td><?php  echo $info["New_Deaths"] ?></td>
                <td><?php  echo $info["Population"] ?></td>
                <td><?php  echo $info["Population_Density"] ?></td>
                <td><?php  echo $info["Median_Age"] ?></td>
                <td><?php  echo $info["Aged_65_Older"] ?></td>
                <td><?php  echo $info["Aged_70_Older"] ?></td>
                <td><?php  echo $info["GDP_Per_Capita"] ?></td>
                <td><?php  echo $info["Extreme_Poverty"] ?></td>
                <td><?php  echo $info["Cardiovasc_Death_Rate"] ?></td>
                <td><?php  echo $info["Diabetes_Prevalence"] ?></td>
                <td><?php  echo $info["Female_Smokers"] ?></td>
                <td><?php  echo $info["Male_Smokers"] ?></td>
                <td><?php  echo $info["Handwashing_Facilities"] ?></td>
                <td><?php  echo $info["Hospital_Beds_Per_Thousand"] ?></td>
                <td><?php  echo $info["Life_Expectancy"] ?></td>
                <td><?php  echo $info["Human_Development_Index   "] ?></td>
            </tr>
            <?php  endforeach; ?>
        </table>
        <div id="box"></div>
    </div>

    <script src="static/js/columnDrag.js"></script>
    
</body>
</html>
