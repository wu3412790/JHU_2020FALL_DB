
<link rel="stylesheet" href="static/css/normalize.min.css">
<link rel="stylesheet" href="static/css/bootstrapmb.com.css">
<ul id="menu">
    <li class="item"><a href="Final_Project.php" >Home Page</a></li>
    <li class="item"><a href="Search.php">Search</a></li>
    <li class="item"><a href="Data_Visualization.php" >Visualization</a></li>
    <li class="item"><a href="Data_Mining.php" >Data Mining</a></li>
    <li class="item"><a href="Global_Rank.php" >Global Ranking</a></li>
</ul>
<script src="static/js/jquery.min.js"></script>
<script>
    $("#menu").find('.item').each(function (){
        if("<?php echo $_SERVER["PHP_SELF"]?>".replace("/","").replace(".php","")===$(this).text()){
            $(this).addClass("active")
            $(this).siblings().removeClass("active")
        }
        else{
            $(".eeee").addClass("active")
        }
    })
</script>
