<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Final Project</title>
    <script src="static/js/echarts.js"></script>
</head>
<body>
<?php
define("PATH", dirname(__FILE__));
include 'Config/DB_class.php';
$db = new DB_class();
$sql = "SELECT country_info.Country,country_info.Continent,sum(daily_global.New_Cases),sum(daily_global.New_Deaths) FROM
country_info RIGHT  JOIN daily_global ON country_info.Country_Code=daily_global.Country_Code GROUP BY country_info.Country;";
$result = $db->query($sql);
$infos1 = array();
while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
    $infos1[] = $row;
}
?>
<?php
include "Header.php"
?>
<div id="main" style="width: 1080px;height: 720px;margin: 0px auto"></div>
<script>
    <?php foreach($infos1 as $rows):?>
    console.log("<?php echo $rows['Country'] ?>")
    <?php endforeach; ?>
</script>
<script type="text/javascript" src="static/js/world.js"></script>
<script>

    var myChart = echarts.init(document.getElementById('main'));
    var option = {
        tooltip: {
            trigger: 'item',
            formatter: function (params) {
                try {
                    var val1 = params['data'].value
                    var val2 = params['data'].value1
                    return params.seriesName + '<br/>Country:' + params.name + '<br/>' + '(1) Total Cases: ' + val1 + '<br/>(2) Total Deaths:' + val2;
                } catch (err) {

                }
            }
        },
        visualMap: {
            min: 0,
            show: true,
            max: 2000000,
            text: ['High', 'Low'],
            realtime: false,
            calculable: true,
            color: ['DarkRed', 'FireBrick','Red','IndianRed','Salmon','LightSalmon']

        },

        series: [
            {
                name: 'Basic Info.',
                type: 'map',
                mapType: 'world',
                roam: true,
                itemStyle: {
                    emphasis: {label: {show: true}}
                },
                data: [

                    <?php foreach($infos1 as $rows):?>
                    <?php if($rows['Country'] != ""){
                    if ($rows['Country'] == "South Korea") {
                        $country="Korea";
                    }
                    else if ($rows['Country'] == "Mozambique") {
                        $country="Mozambique";
                    }else if ($rows['Country'] == "Central African Republic") {
                        $country="Central African Rep.";
                    }else if ($rows['Country'] == "South Sudan") {
                        $country="S. Sudan";
                    }else if ($rows['Country'] == "Western Sahara") {
                        $country="W. Sahara";
                    }else if ($rows['Country'] == "Cote d'Ivoire") {
                        $country="CÃ´te d'Ivoire";
                    }else if ($rows['Country'] == "Democratic Republic of Congo") {
                        $country="Dem. Rep. Congo";
                    }else if ($rows['Country'] == "Equatorial Guinea") {
                        $country="Eq. Guinea";
                    }else if ($rows['Country'] == "Timor") {
                        $country="Timor-Leste";
                    }else if ($rows['Country'] == "Laos") {
                        $country="Lao PDR";
                    }else if ($rows['Country'] == "Solomon Islands") {
                        $country="Solomon Is.";
                    }else if ($rows['Country'] == "Dominican Republic") {
                        $country="Dominican Rep.";
                    }else if ($rows['Country'] == "Antigua and Barbuda") {
                        $country="Antigua and Barb.";
                    }else if ($rows['Country'] == "Zambia") {
                        $country="Zambia";
                    }
                    else {
                        $country = $rows['Country'];
                    }
                    ?>
                    <?php $val1 = $rows['sum(daily_global.New_Cases)'];
                    if ($val1 == "null" || $val1 === null) {
                        $val1 = 0.0;
                    }
                    ?>
                    <?php $val2 = $rows['sum(daily_global.New_Deaths)'];
                    if ($val2 == "null" || $val2 === null) {
                        $val2 = 0.0;
                    }
                    ?>

                    {name: "<?php echo $country ?>", value:<?php echo $val1 ?>, value1:<?php echo $val2 ?>},
                    <?php   }?>

                    <?php endforeach;?>
                    {name: "", value: 4444, value1: 44444},
                ]
            }
        ]
    };
    myChart.setOption(option);
</script>
</body>
</html>