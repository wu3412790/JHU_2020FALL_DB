<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Global Ranking</title> //基于Bootstrap表格导出Excel插件
    <link rel="stylesheet" type="text/css" href="https://cdn.bootcss.com/twitter-bootstrap/3.4.1/css/bootstrap.min.css"><!--包含图标库-->
    <link rel="stylesheet" href="static/table/bootstrap/css/bootstrap-table.css" />



</head>
<body>
<?php
include "Header.php"
?>
<div id="reportTableDiv" class="span10" style="width:70%;margin: 0 auto">
    <table id="reportTable"></table>
</div>
<?php
define("PATH", dirname(__FILE__));
include 'Config/DB_class.php';
$db = new DB_class();
$sql="SELECT sum(daily_global.New_Cases),sum(daily_global.New_Deaths),country_info.Country,country_info.Population,country_info.Life_Expectancy FROM daily_global RIGHT JOIN country_info ON country_info.Country_Code=daily_global.Country_Code WHERE (country_info.Life_Expectancy+0) >0 GROUP BY country_info.Country ORDER BY sum(daily_global.New_Cases) DESC";
$result = $db->query($sql);
$infos1 = array();
while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
    $infos1[] = $row;
}
?>

<script src="static/table/js/jquery.min.js"></script>
<script src="static/table/js/bootstrap.min.js"></script>
<script src="static/table/bootstrap/js/bootstrap-table.js"></script>
<script src="static/table/bootstrap/js/bootstrap-table-export.js"></script>
<script src="static/table/bootstrap/js/jquery.base64.js"></script>
<script src="static/table/bootstrap/js/tableExport.js"></script>
<script type="text/javascript">
    $(function () {
        $('#reportTable').bootstrapTable({
            method: 'get',
            cache: false,
            height: 500,
            // striped: true,
            pagination: true,
            pageSize: 10,
            pageNumber: 1,
            // pageList: [10, 20, 50, 100, 200, 500],
            // search: true,
            showColumns: true,
            // showRefresh: true,
            // showExport: true,
            exportTypes: ['excel'],
            // clickToSelect: true,
            columns: [
                { field: "Country", title: "Country", align: "center", valign: "middle", sortable: "true" },
                { field: "Totle_Cases", title: "Totle_Cases", align: "center", valign: "middle", sortable: "true" },
                { field: "Totle_Deaths", title: "Totle_Deaths", align: "center", valign: "middle", sortable: "true" },
                { field: "Population", title: "Population", align: "center", valign: "middle", sortable: "true" },

            ],
            data: [
                <?php foreach ($infos1 as $info): ?>
                {"Country":"<?php echo $info['Country'] ?>",
                    "Totle_Cases":"<?php echo $info['sum(daily_global.New_Cases)'] ?>",
                    "Totle_Deaths":"<?php echo $info['sum(daily_global.New_Deaths)'] ?>",
                    "Population": "<?php echo $info['Population'] ?>"
                },
                <?php endforeach;?>
            ],


        });
        $(window).resize(function () {
            $('#reportTable').bootstrapTable('resetView');
        });
    });

</script>

</body>
</html>