<!DOCTYPE html>
<html >
<head>
    <meta charset="UTF-8">
    <title>Data Visualization</title>
    <script src="static/js/echarts.js"></script>
    <script src="static/js/Bubble.js"></script>
    <link rel="stylesheet" href="static/css/Bubble.css">
</head>
<body>
<?php include "Header.php";
?>

<?php
define("PATH", dirname(__FILE__));
include 'Config/DB_class.php';
include 'Config/db_method.php';
$db = new DB_class();
$sql="SELECT Country FROM country_info limit 50";
$result = $db->query($sql);
$infos = array();
while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
    $infos[] = $row;
}
?>
<div class="wrapper">
    <div class="tagcloud">
        <?php foreach($infos as $rows):?>
            <a class="b04 co06" href="#"><?php echo $rows['Country'] ?></a>
        <?php endforeach;?>
    </div>
</div>
<script type="text/javascript">
    tagcloud({
        selector: ".tagcloud",
        fontsize: 16,
        radius: 140,
        mspeed: "slow",
        ispeed: "slow",
        direction: 135,
        keep: false
    });
</script>
<?php
$_country=$_POST['country'];
if($_country!=""){
    $infos1=get_Country($db,$_country);
}

else{
    $infos1=get_Country($db,"United States");
}


?>
<div>
    <div class="search">
        <form id="search" method="post">
            <input id="country" type="text" name="country" placeholder="country">
            <input type="submit" value="search">

        </form>
    </div>
<div id="box" style="width: 750px;height: 400px;margin-top: 100px;"></div>
</div>
<script>

    var myChart=echarts.init(document.getElementById("box"));
    var option={
        title:{
            text:'<?php echo $infos1[0]['Country'] ?>'
        },
        legend:{
            data:['Add']
        },
        //x-axis
        xAxis:{
            data:[
                <?php foreach ($infos1 as $info): ?>
                "<?php echo $info['Date_Recorded'] ?>",
                <?php endforeach; ?>
            ]
        },
        tooltip: {},
        yAxis:{},

        series:[{
            name:'increase quantity',
            type:'line',
            data:[<?php foreach ($infos1 as $info): ?>
                <?php echo (int)$info['New_Cases'] ?>,
                <?php endforeach; ?>]
        }]
    };
    myChart.setOption(option);
</script>
<script src="static/js/jquery.min.js"></script>
<script>
    $(".tagcloud").on('click','a',function (){
        $("#country").val($(this).text());
        $("#search").submit()
    })
</script>
</body>


</html>