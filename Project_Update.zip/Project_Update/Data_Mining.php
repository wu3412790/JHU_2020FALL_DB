<?php include "Header.php" ?>
<div style="height: 10px"></div>
<?php
define("PATH", dirname(__FILE__));
include 'Config/DB_class.php';
include 'Config/db_method.php';
$db = new DB_class();
$keyword=$_POST["keyword"];
?>
<?php


if(!$keyword){
    $keyword="Life_Expectancy";
    $sql = "SELECT sum(daily_global.New_Cases),country_info.Population,country_info.Life_Expectancy FROM daily_global RIGHT JOIN country_info ON country_info.Country_Code=daily_global.Country_Code WHERE (country_info.Life_Expectancy+0) >0 GROUP BY country_info.Country ORDER BY country_info.Life_Expectancy;";
}
else{
    $keyword=$keyword;
    $sql = "SELECT sum(daily_global.New_Cases),country_info.Population,country_info.$keyword FROM daily_global RIGHT JOIN country_info ON country_info.Country_Code=daily_global.Country_Code WHERE (country_info.$keyword+0) >0 GROUP BY country_info.Country ORDER BY country_info.$keyword;";
}



$result = $db->query($sql);
$infos1 = array();
while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
    $infos1[] = $row;
}
?>
<script>
    var values=[<?php foreach ($infos1 as $info): ?>
        <?php echo (int)$info["sum(daily_global.New_Cases)"]/((int)$info["Population"]/1000000) ?>,
        <?php endforeach; ?>]
    var title="<?php echo $keyword ?>";
</script>
<?php
?>
<link rel="stylesheet" href="static/css/chart.css">
<form hidden method="post" id="form">
    <input type="text" name="keyword" id="keyword">
    <input type="submit">
</form>
<div class="bg">
    <ul class="nav nav-pills">

        <li data-name="Population">
            <b>Population</b>
        </li>
        <li data-name="Population_Density">
            <b>Population_Density</b>
        </li>
        <li data-name="Median_Age">
            <b>Median_Age</b>
        </li>
        <li data-name="Aged_65_Older">
            <b>Aged_65_Older</b>
        </li>
        <li data-name="Aged_70_Older">
            <b>Aged_70_Older</b>
        </li>
        <li data-name="GDP_Per_Capita">
            <b>GDP_Per_Capita</b>
        </li>
        <li data-name="Extreme_Poverty">
            <b>Extreme_Poverty</b>
        </li>
        <li data-name="Cardiovasc_Death_Rate">
            <b>Cardiovasc_Death_Rate</b>
        </li>
        <li data-name="Diabetes_Prevalence">
            <b>Diabetes_Prevalence</b>
        </li>
        <li data-name="Female_Smokers">
            <b>Female_Smokers</b>
        </li>
        <li data-name="Male_Smokers">
            <b>Male_Smokers</b>
        </li>
        <li data-name="Handwashing_Facilities">
            <b>Handwashing_Facilities</b>
        </li>
        <li data-name="Hospital_Beds_Per_Thousand">
            <b>Hospital_Beds_Per_Thousand</b>
        </li>
        <li data-name="Life_Expectancy">
            <b>Life_Expectancy</b>
        </li>
        <li data-name="Human_Development_Index">
            <b>Human_Development_Index </b>
        </li>
    </ul>
</div>
<div id="box" style="width: 1200px;height: 400px;margin: 100px auto"></div>
<script src="static/js/jquery.min.js"></script>
<script>
    $(".nav-pills").on('click','li',function (){
        console.log($(this).data("name"))
        $("#keyword").val($(this).data("name"))
        $("#form").submit()
    })
</script>
<script src="static/js/echarts.js"></script>

<script>
    var myChart = echarts.init(document.getElementById("box"));
    var option = {

        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['add']
        },

        xAxis: {
            name:title,
            type: 'category',
            boundaryGap: false,
            data: [<?php foreach ($infos1 as $info): ?>
                "<?php echo $info[$keyword] ?>",
                <?php endforeach; ?>]
        },
        yAxis: {
            name:"Total Cases Per Million",
            type: 'value',
            axisLabel: {
                formatter: '{value}'
            }
        },
        series: [
            {
                name: "<?php echo $keyword?>",
                type: 'line',
                data: values,
                markPoint: {
                    data: [
                        {type: 'max', name: 'Maximum'},
                        {type: 'min', name: 'Minimum'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: 'Average'}
                    ]
                }
            },

        ]};
    myChart.setOption(option);
</script>
